//
//  AlertsViewController.swift
//  FutureWeather
//
//  Created by Mahdi Mohammadzadeh on 8/11/18.
//  Copyright © 2018 Mahdi Mohammadzadeh. All rights reserved.
//

import UIKit

class AlertsViewController: UIViewController {
    
    @IBOutlet weak var textView: UITextView!
    
    var alerts: [Alert]?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        let descriptions: [String]? = alerts?.flatMap({ $0.message })
        textView.text = descriptions?.joined(separator: "\n")
        textView.contentOffset = .zero
    }
    
}

