//
//  ForecastHourCellViewModel.swift
//  FutureWeather
//
//  Created by Mahdi Mohammadzadeh on 8/11/18.
//  Copyright © 2018 Mahdi Mohammadzadeh. All rights reserved.
//

import Foundation
import UIKit

class ForecastHourCellViewModel {
    
    static private let dateFormatter: DateFormatter = {
        let df = DateFormatter()
        df.dateFormat = "h a"
        return df
    }()
    
    let date: Date
    let temp: Int
    let conditionImageName: String
    let chancePrecip: Double
    
    init(date: Date, temp: Int, conditionImageName: String, chancePrecip: Double) {
        self.date = date
        self.temp = temp
        self.conditionImageName = conditionImageName
        self.chancePrecip = chancePrecip
    }
    
    var dateString: String {
        return ForecastHourCellViewModel.dateFormatter.string(from: date)
    }
    
    var detailsAttributedString: NSAttributedString {
        let fontSize: CGFloat = 15
        let mAttrString = NSMutableAttributedString(
            string: String(format: "%zi°", temp),
            attributes: [NSAttributedStringKey.font: UIFont.systemFont(ofSize: fontSize, weight: UIFont.Weight.medium)]
        )
        if chancePrecip >= 0.2 {
            let percipAttrStr = NSAttributedString(
                string: String(format: " %.0f%%", round(chancePrecip * 10.0) * 10.0),
                attributes: [
                    NSAttributedStringKey.font: UIFont.systemFont(ofSize: fontSize, weight: UIFont.Weight.light),
                    NSAttributedStringKey.foregroundColor: UIColor(red: 73/255.0, green: 130/255.0, blue: 193/255.0, alpha: 1)
                ]
            )
            mAttrString.append(percipAttrStr)
        }
        return mAttrString
    }
    
}

