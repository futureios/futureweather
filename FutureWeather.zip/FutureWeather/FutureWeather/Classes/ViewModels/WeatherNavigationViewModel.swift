//
//  WeatherNavigationViewModel.swift
//  FutureWeather
//
//  Created by Mahdi Mohammadzadeh on 8/11/18.
//  Copyright © 2018 Mahdi Mohammadzadeh. All rights reserved.
//

import Foundation

func WeatherNavigationTitle(location: SavedLocation, forecast: Forecast?) -> String? {
    if location.userLocation == true {
        if let forecast = forecast {
            return forecast.location?.city
        } else {
            return NSLocalizedString("Loading...", comment: "")
        }
    } else {
        return location.name
    }
}

func WeatherNavigationShouldDisplayAlerts(forecast: Forecast?) -> Bool {
    return (forecast?.alerts?.count ?? 0) > 0
}

