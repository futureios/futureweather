//
//  SavedLocationCellViewModel.swift
//  FutureWeather
//
//  Created by Mahdi Mohammadzadeh on 8/11/18.
//  Copyright © 2018 Mahdi Mohammadzadeh. All rights reserved.
//

import Foundation
import MapKit

struct SavedLocationCellViewModel {
    let text: String
    let userLocation: Bool
    let region: MKCoordinateRegion
}

