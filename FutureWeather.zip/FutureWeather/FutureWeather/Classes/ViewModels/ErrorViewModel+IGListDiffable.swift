//
//  ErrorViewModel+IGListDiffable.swift
//  FutureWeather
//
//  Created by Mahdi Mohammadzadeh on 8/11/18.
//  Copyright © 2018 Mahdi Mohammadzadeh. All rights reserved.
//

import IGListKit

extension ErrorViewModel: ListDiffable {
    
    func diffIdentifier() -> NSObjectProtocol {
        return title as NSString
    }
    
    func isEqual(toDiffableObject object: ListDiffable?) -> Bool {
        if self === object { return true }
        guard let object = object as? ErrorViewModel else { return false }
        return type == object.type
            && title == object.title
            && message == object.message
    }
    
}

