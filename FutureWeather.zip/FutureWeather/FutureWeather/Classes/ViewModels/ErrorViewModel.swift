//
//  ErrorViewModel.swift
//  FutureWeather
//
//  Created by Mahdi Mohammadzadeh on 8/11/18.
//  Copyright © 2018 Mahdi Mohammadzadeh. All rights reserved.
//

import Foundation

enum ErrorViewModelType {
    case location
    case network
}

class ErrorViewModel {
    
    let title: String
    let message: String
    let type: ErrorViewModelType
    
    init(title: String, message: String, type: ErrorViewModelType) {
        self.title = title
        self.message = message
        self.type = type
    }
    
}

