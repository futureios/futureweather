//
//  ForecastHourlyDataSource.swift
//  FutureWeather
//
//  Created by Mahdi Mohammadzadeh on 8/11/18.
//  Copyright © 2018 Mahdi Mohammadzadeh. All rights reserved.
//

import Foundation
import IGListKit

class ForecastHourlyDataSource: EmbeddedAdapterDataSource {
    
    func listAdapter(_ listAdapter: ListAdapter, sectionControllerFor object: Any) -> ListSectionController {
        if object is ForecastHourCellViewModel {
            return HourlyForecastSectionController()
        }
        return ListSectionController()
    }
    
}

