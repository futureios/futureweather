//
//  ForecastDayCellViewModel+Equatable.swift
//  FutureWeather
//
//  Created by Mahdi Mohammadzadeh on 8/11/18.
//  Copyright © 2018 Mahdi Mohammadzadeh. All rights reserved.
//

import Foundation

extension ForecastDayCellViewModel: Equatable {
    
    public static func ==(lhs: ForecastDayCellViewModel, rhs: ForecastDayCellViewModel) -> Bool {
        return lhs.date == rhs.date
            && lhs.high == rhs.high
            && lhs.low == rhs.low
            && lhs.conditionImageName == rhs.conditionImageName
    }
    
}

