//
//  MKCoordinateRegion+Convenience.swift
//  FutureWeather
//
//  Created by Mahdi Mohammadzadeh on 8/11/18.
//  Copyright © 2018 Mahdi Mohammadzadeh. All rights reserved.
//

import MapKit
import UIKit

extension MKCoordinateRegion {
    
    init(center: CLLocationCoordinate2D, width: CLLocationDegrees, size: CGSize) {
        let ratio = size.width / size.height
        let span = MKCoordinateSpan(latitudeDelta: width, longitudeDelta: Double(ratio) * width)
        self.init(center: center, span: span)
    }
    
}

