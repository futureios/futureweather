//
//  URLBuilder.swift
//  FutureWeather
//
//  Created by Mahdi Mohammadzadeh on 8/11/18.
//  Copyright © 2018 Mahdi Mohammadzadeh. All rights reserved.
//

import Foundation

func URLBuilder(base: String, paths: [String]? = nil, query: [String: String]? = nil) -> URL? {
    guard let baseURL = URL(string: base) else { preconditionFailure("Base not convertible to URL: " + base) }
    var components = URLComponents(url: baseURL, resolvingAgainstBaseURL: false)
    components?.queryItems = query?
        .map { (k, v) in URLQueryItem(name: k, value: v) }
    components?.path = "/" + (paths?.joined(separator: "/") ?? "")
    return components?.url
}

