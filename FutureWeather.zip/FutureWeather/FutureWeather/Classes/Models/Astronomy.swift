//
//  Astronomy.swift
//  FutureWeather
//
//  Created by Mahdi Mohammadzadeh on 8/11/18.
//  Copyright © 2018 Mahdi Mohammadzadeh. All rights reserved.
//

import Foundation

struct Astronomy {
    
    let sunrise: Date
    let sunset: Date
    let moonrise: Date
    let moonset: Date
    let moonIllumination: Double
    let moonAge: Int
    let moonPhaseDescription: String
    let moonHemisphere: String
    
}

