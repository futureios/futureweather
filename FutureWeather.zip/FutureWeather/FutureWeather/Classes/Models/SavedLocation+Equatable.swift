//
//  SavedLocation+Equatable.swift
//  FutureWeather
//
//  Created by Mahdi Mohammadzadeh on 8/11/18.
//  Copyright © 2018 Mahdi Mohammadzadeh. All rights reserved.
//

import Foundation

// SavedLocation inherits from NSObject so not using Equatable protocol
func ==(lhs: SavedLocation, rhs: SavedLocation) -> Bool {
    return lhs.userLocation == rhs.userLocation
        && lhs.latitude == rhs.latitude
        && lhs.longitude == rhs.longitude
        && lhs.name == rhs.name
}

