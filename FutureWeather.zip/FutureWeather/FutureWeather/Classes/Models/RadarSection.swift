//
//  RadarSection.swift
//  FutureWeather
//
//  Created by Mahdi Mohammadzadeh on 8/11/18.
//  Copyright © 2018 Mahdi Mohammadzadeh. All rights reserved.
//

import Foundation
import CoreLocation
import MapKit

class RadarSection: NSObject {
    
    let center: CLLocationCoordinate2D
    
    init(center: CLLocationCoordinate2D) {
        self.center = center
    }
    
}

