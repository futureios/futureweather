//
//  JSONConvertible.swift
//  FutureWeather
//
//  Created by Mahdi Mohammadzadeh on 8/11/18.
//  Copyright © 2018 Mahdi Mohammadzadeh. All rights reserved.
//

import Foundation

protocol JSONConvertible {
    static func fromJSON(json: [String: Any]) -> Self?
}

