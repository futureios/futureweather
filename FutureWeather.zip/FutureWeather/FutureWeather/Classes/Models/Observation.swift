//
//  Observation.swift
//  FutureWeather
//
//  Created by Mahdi Mohammadzadeh on 8/11/18.
//  Copyright © 2018 Mahdi Mohammadzadeh. All rights reserved.
//

import Foundation

struct Observation {
    
    let date: Date
    let weather: String
    let temp: Double
    let humidity: String
    let wind: Wind
    let pressure: Double
    let dewpoint: Double
    let feelslike: Int
    let visibility: Double
    let uvi: Int
    let precip_1hr: Double
    let precip_day: Double
    let condition: Condition
    
}

