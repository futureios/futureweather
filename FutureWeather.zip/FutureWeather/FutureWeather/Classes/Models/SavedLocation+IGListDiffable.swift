//
//  SavedLocation+IGListDiffable.swift
//  FutureWeather
//
//  Created by Mahdi Mohammadzadeh on 8/11/18.
//  Copyright © 2018 Mahdi Mohammadzadeh. All rights reserved.
//

import Foundation
import IGListKit

extension SavedLocation: ListDiffable {
    
    func diffIdentifier() -> NSObjectProtocol {
        return name as NSString
    }
    
    func isEqual(toDiffableObject object: ListDiffable?) -> Bool {
        if self === object { return true }
        guard let rhs = object as? SavedLocation else { return false }
        return name == rhs.name
            && latitude == rhs.latitude
            && longitude == rhs.longitude
            && userLocation == rhs.userLocation
    }
    
}

