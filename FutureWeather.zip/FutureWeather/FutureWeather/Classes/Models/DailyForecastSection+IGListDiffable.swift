//
//  DailyForecastSection+IGListDiffable.swift
//  FutureWeather
//
//  Created by Mahdi Mohammadzadeh on 8/11/18.
//  Copyright © 2018 Mahdi Mohammadzadeh. All rights reserved.
//

import Foundation
import IGListKit

extension DailyForecastSection: ListDiffable {
    
    func diffIdentifier() -> NSObjectProtocol {
        return "daily" as NSString
    }
    
    func isEqual(toDiffableObject object: ListDiffable?) -> Bool {
        if self === object { return true }
        guard let object = object as? DailyForecastSection else { return false }
        return viewModels == object.viewModels
    }
    
}

