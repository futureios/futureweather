//
//  Forecast.swift
//  FutureWeather
//
//  Created by Mahdi Mohammadzadeh on 8/11/18.
//  Copyright © 2018 Mahdi Mohammadzadeh. All rights reserved.
//

import Foundation

struct Forecast {
    
    let location: Location?
    let observation: Observation?
    let alerts: [Alert]?
    let daily: [ForecastDay]?
    let hourly: [ForecastHourly]?
    let astronomy: Astronomy?
    
}

