//
//  EmbeddedSection.swift
//  FutureWeather
//
//  Created by Mahdi Mohammadzadeh on 8/11/18.
//  Copyright © 2018 Mahdi Mohammadzadeh. All rights reserved.
//

import Foundation
import IGListKit

class EmbeddedSection {
    
    let identifier: NSObjectProtocol
    let items: [ListDiffable]
    
    init(identifier: NSObjectProtocol, items: [ListDiffable]) {
        self.identifier = identifier
        self.items = items
    }
    
}

