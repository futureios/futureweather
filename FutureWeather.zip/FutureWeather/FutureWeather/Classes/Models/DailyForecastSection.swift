//
//  DailyForecastSection.swift
//  FutureWeather
//
//  Created by Mahdi Mohammadzadeh on 8/11/18.
//  Copyright © 2018 Mahdi Mohammadzadeh. All rights reserved.
//

import Foundation

class DailyForecastSection {
    
    let currentDate: Date
    let viewModels: [ForecastDayCellViewModel]
    
    init(currentDate: Date, viewModels: [ForecastDayCellViewModel]) {
        self.currentDate = currentDate
        self.viewModels = viewModels
    }
    
}

