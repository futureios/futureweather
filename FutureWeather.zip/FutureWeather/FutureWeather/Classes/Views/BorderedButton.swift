//
//  BorderedButton.swift
//  FutureWeather
//
//  Created by Mahdi Mohammadzadeh on 8/11/18.
//  Copyright © 2018 Mahdi Mohammadzadeh. All rights reserved.
//

import UIKit

class BorderedButton: UIButton {
    
    lazy var shapeLayer: CAShapeLayer = {
        let l = CAShapeLayer()
        l.lineWidth = 1
        l.fillColor = nil
        self.layer.addSublayer(l)
        return l
    }()
    
    override func layoutSubviews() {
        super.layoutSubviews()
        shapeLayer.path = UIBezierPath(roundedRect: bounds, cornerRadius: 6).cgPath
        shapeLayer.strokeColor = tintColor.cgColor
    }
    
}

