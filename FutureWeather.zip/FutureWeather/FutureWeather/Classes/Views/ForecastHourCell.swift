//
//  ForecastHourCell.swift
//  FutureWeather
//
//  Created by Mahdi Mohammadzadeh on 8/11/18.
//  Copyright © 2018 Mahdi Mohammadzadeh. All rights reserved.
//

import UIKit

class ForecastHourCell: RoundedCollectionViewCell {
    
    @IBOutlet weak var timeLabel: UILabel!
    @IBOutlet weak var tempLabel: UILabel!
    @IBOutlet weak var iconImageView: UIImageView!
    
    func configure(viewModel: ForecastHourCellViewModel) {
        cornerOptions = .all
        timeLabel.text = viewModel.dateString
        tempLabel.attributedText = viewModel.detailsAttributedString
        iconImageView.image = UIImage(named: viewModel.conditionImageName)
    }
    
}
