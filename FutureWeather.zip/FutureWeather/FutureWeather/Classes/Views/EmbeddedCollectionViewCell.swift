//
//  EmbeddedCollectionViewCell.swift
//  FutureWeather
//
//  Created by Mahdi Mohammadzadeh on 8/11/18.
//  Copyright © 2018 Mahdi Mohammadzadeh. All rights reserved.
//

import UIKit
import IGListKit

class EmbeddedCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var collectionView: ListCollectionView! {
        didSet {
            collectionView.bounces = true
            collectionView.alwaysBounceVertical = false
            collectionView.alwaysBounceHorizontal = true
        }
    }
    
}

