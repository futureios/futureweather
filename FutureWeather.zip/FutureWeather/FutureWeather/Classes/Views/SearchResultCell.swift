//
//  SearchResultCell.swift
//  FutureWeather
//
//  Created by Mahdi Mohammadzadeh on 8/11/18.
//  Copyright © 2018 Mahdi Mohammadzadeh. All rights reserved.
//

import UIKit

class SearchResultCell: UICollectionViewCell {
    
    @IBOutlet weak var label: UILabel!
    @IBOutlet weak var detailLabel: UILabel!
    
    @IBOutlet weak var labelVerticalConstraint: NSLayoutConstraint!
    
}

