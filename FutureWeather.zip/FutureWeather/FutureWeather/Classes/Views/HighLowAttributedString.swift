//
//  HighLowAttributedString.swift
//  FutureWeather
//
//  Created by Mahdi Mohammadzadeh on 8/11/18.
//  Copyright © 2018 Mahdi Mohammadzadeh. All rights reserved.
//

import Foundation
import UIKit

func highLowAttributedString(high: Int, low: Int, size: CGFloat = 15) -> NSAttributedString {
    let font = UIFont.systemFont(ofSize: size, weight: UIFont.Weight.medium)
    let mstr = NSMutableAttributedString(
        string: String(format: "%zi°", high),
        attributes: [
            NSAttributedStringKey.font: font,
            NSAttributedStringKey.foregroundColor: UIColor.white
        ])
    mstr.append(NSAttributedString(
        string: String(format: " %zi°", low),
        attributes: [
            NSAttributedStringKey.font: font,
            NSAttributedStringKey.foregroundColor: UIColor(white: 0.733333333, alpha: 1)
        ]))
    return mstr
}

