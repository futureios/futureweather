//
//  RetryCell.swift
//  FutureWeather
//
//  Created by Mahdi Mohammadzadeh on 8/11/18.
//  Copyright © 2018 Mahdi Mohammadzadeh. All rights reserved.
//

import UIKit

protocol RetryCellDelegate: class {
    func retryCellDidTapRetry(retryCell: RetryCell)
}

class RetryCell: UICollectionViewCell {
    
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var messageLabel: UILabel!
    @IBOutlet weak var retryButton: BorderedButton!
    
    weak var delegate: RetryCellDelegate?
    
    @IBAction func onRetry(_ sender: Any) {
        delegate?.retryCellDidTapRetry(retryCell: self)
    }
    
}

